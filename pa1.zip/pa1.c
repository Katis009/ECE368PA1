


void main(){

    int size;
    char filename = scanf();

    long array =  Array_Load_From_File(&filename, &size);
    
}